package com.rest.api;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payment")
public class PaymentController extends Thread {

	Thread t1 =new Thread();
	
	public void run() {
		List<PaymentRequest> list=new ArrayList<PaymentRequest>();
		PaymentRequest payreq=new PaymentRequest();
		while(!t1.isInterrupted()) {
			Random rand = new Random(); 
			int userId = rand.nextInt(1000);
			double discount = rand.nextDouble();
			 byte[] array = new byte[7]; 
			    new Random().nextBytes(array);
			    String itemId = new String(array, Charset.forName("UTF-8"));
			 
			    payreq.setItemId(itemId);
				payreq.setUserId(userId);
				payreq.setDiscount(discount);
			
			list.add(payreq);
		}
		
		
	}
	
	
	
	@RequestMapping(value="/start",method=RequestMethod.GET)
	public BaseResponse startAPI() {
		
		BaseResponse response=new BaseResponse();

		t1=new Thread();

		t1.start();
			if(t1.isAlive()) {
				
				response.setStatus("Data is being processed");
				response.setCode(200);
			}
		return response;
	}
	
	@RequestMapping(value="/stop",method=RequestMethod.GET)
	public BaseResponse stopAPI() {
		BaseResponse response=new BaseResponse();
		t1.interrupt();
		
			 response.setStatus("Data is disrupted"); 
			 response.setCode(200);
		
		return response;
	}
	
	
	
	
}
