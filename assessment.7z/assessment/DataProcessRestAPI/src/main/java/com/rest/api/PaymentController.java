package com.rest.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payment")
public class PaymentController {

	private final String sharedKey="SHARED_KEY";
	
	
	private static final String SUCCESS_STATUS="success";
	private static final String ERROR_STATUS="Data already disrupted";
	private static final int CODE_SUCCESS=100;
	private static final int AUTH_FAILURE=102;
	List<PaymentRequest> list=new ArrayList<PaymentRequest>();
	PaymentRequest payreq=new PaymentRequest();
	@RequestMapping(value="/start",method=RequestMethod.POST)
	public BaseResponse start(@RequestBody PaymentRequest request) {
		
		BaseResponse response=new BaseResponse();
		
			int userId=request.getUserId();
			String itemId=request.getItemId();
			double discount=request.getDiscount();
			
			payreq.setItemId(itemId);
			payreq.setUserId(userId);
			payreq.setDiscount(discount);
			
			list.add(payreq);
			
			response.setStatus(SUCCESS_STATUS);
			response.setCode(CODE_SUCCESS);
			
	
		
		System.out.println("list size start"+list.size());
		return response;
	}
	
	@RequestMapping(value="/stop",method=RequestMethod.POST)
	public BaseResponse stop(@RequestBody PaymentRequest request) {
		BaseResponse response=new BaseResponse();
		
		if(list.size()>1) {
			
			response.setStatus(ERROR_STATUS);
			response.setCode(AUTH_FAILURE);
		}else {
			response.setStatus(SUCCESS_STATUS);
			response.setCode(CODE_SUCCESS);
			
		}
		return response;
	}
}
